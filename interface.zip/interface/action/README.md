+ login.php  -- 登录

    {
      
    }

+ signup.php -- 注册
    
    // client
    {
      "phone": 18777777777, 
      "password": "admin",
      "confirm_password": "admin",
      "code": "code" //验证码
    }
    
    //server
    1000 手机号格式错误
    1001 密码格式错误
    
    
+ home_recommend.php -- 首页推荐    

  
    
   
    
    
    
    
    
    
    
    
